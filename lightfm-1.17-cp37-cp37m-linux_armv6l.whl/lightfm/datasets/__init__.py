from lightfm.datasets.movielens import fetch_movielens  # NOQA
from lightfm.datasets.stackexchange import fetch_stackexchange  # NOQA
